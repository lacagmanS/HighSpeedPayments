package com.paymentsprocessor.highspeedpayments;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HighspeedPaymentsApplicationTests {

	@Test
	void contextLoads() {
	}

}
